package controllers;

import play.mvc.*;
import play.data.*;
import javax.inject.Inject;

import views.html.*;
import play.db.ebean.Transactional;
import play.api.Environment;

import models.users.*;
import models.game;
import models.shopping.*;

@Security.Authenticated(Secured.class)
@With(CheckIfCustomer.class)

public class ShoppingCtrl extends Controller{
    private FormFactory formFactory;

    private Environment env;

    public ShoppingCtrl(Environment e, FormFactory f){
        this.env = e;
        this.formFactory = f;

        private Customer getCurrentUser(){
            return (Customer)User.getLoggedIn(session().get("email"));

        }

        @Transactional
        public Result showBasket(){
            return ok(basket.render(getCurrentUser()));
        }

        @Transactional
        public Result addToBasket(Long id){
            game g = Game.find.byId(id);
            Customer customer = (Customer)
        }

    }
}