package controllers;

import play.mvc.*;
import play.data.*;
import javax.inject.Inject;

import views.html.*;
import play.db.ebean.Transactional;
import play.api.Environment;

import models.users.*;
import models.game;
import models.Shopping.*;

@Security.Authenticated(Secured.class)
@With(CheckIfCustomer.class)

public class ShoppingCtrl extends Controller{
    private FormFactory formFactory;

    private Environment env;

    public ShoppingCtrl(Environment e, FormFactory f){
        this.env = e;
        this.formFactory = f;

        private Customer getCurrentUser(){
            return (Customer)User.getLoggedIn(session().get("email"));

        }

        @Transactional
        public Result showBasket(){
            return ok(basket.render(getCurrentUser()));
        }

        @Transactional
        public Result addToBasket(Long id){
            game g = Game.find.byId(id);
            Customer customer = (Customer)User.getLoggedIn(session().get("email"));

            if(customer.getBasket() == null){
                customer.setBasket(new basket());
                customer.getBasket().setCustomer(customer);
                customer.update();
            }
            return ok(basket.render(customer));
        }
        @Transactional
        public Result removeOne(Long gameId){
            Game item = Game.find.byId(gameId);
            Customer c = getCurrentUser();
            c.getBasket().removeItem(item);
            c.getBasket().update();

            return ok(basket.render(c));
        }

        @Transactional 
        public Result emptyBasket(){
            Customer c = getCurrentUser();
            c.getBasket().removeAllItems();
            c.getBasket().update();

            return ok(basket.render(c));
        }
        @Transactional
        public Result viewOrder(Long id){
            ShopOrder order = ShopOrder.find.ById(id);
            return ok(orderConfirmed.render(getCurrentUser(), order));
        }

    }
}