package models;

public class GameTags {
}
