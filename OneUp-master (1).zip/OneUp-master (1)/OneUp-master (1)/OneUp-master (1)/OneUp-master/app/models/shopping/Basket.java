package models.shopping;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

import models.users.*;
import models.Game;

@Entity
public class Basket extends Model{
    @Id
    private Long id;

    private List<Game>basketItems;

    private Customer customer;

    public Basket(){

    }

    public void addGame(Game g){
        boolean gameFound = false;
        for(Game i : basketItems){
            if(i.getGame().getId() == g.getId()){
                i.increaseQty();
                gameFound = true;
                break;
            }
        }
        if(gameFound == false ){
            Game game = new Game(g);
            basketItems.add(game);
        }
    }

    public void removeGame(Game game){

        for(Iterator<Game> iter = basketItems.iterator(); iter.hasNext();){
            Game g = iter.next();
            if(g.getId().equals(game.getId())){
                g.delete();
                iter.remove();
                break;
            }
        }
    }
    

    public void removeAllItems(){
        for(Game i: this.basketItems){
            i.delete();
        }
        this.basketItems = null;
    }

    public List<Game> getBasketItems(){

        return basketitems;
    }

    public double getBasketTotal(){

        double total = 0;

        for(Game i: basketitems){
            total += i.getItemTotal();
        }
        return total;
    }
    public static Finder<Long,Basket> find = new Finder<Long,Basket>(Basket.class);

    public static List<Basket> findall(){
        return Basket.find.all;
    }

    public Customer getCustomer(){
        return customer;
    }

    public void setCustomer(Customer customer){
        this.customer = customer;
    }
}
